Rails.application.routes.draw do

  get 'todolists/new'
  get 'top' => 'homes#top'
  #URL「top」にアクセスしたときに、homesコントローラのtopアクションが呼び出されるように設定。
  post 'todolists' => 'todolists#create'
                   #[.../todolists]というURLにpostメソットでリクエストしたときに、
                   #todolistsコントローラーのcreateアクションが呼び出される
  get 'todolists' => 'todolists#index'#「/todolists」のURLでtodolistsコントローラのindexアクションが
                          #実行され,index.html.erbファイルの内容が表示されるようにする
  get 'todolists/:id' => 'todolists#show', as: 'todolist'
       #'todolists#show'の設定を、todolistとして利用できる
  get "todolists/:id/edit" => "todolists#edit", as: "edit_todolist"
       #エディット(編集画面)
  patch "todolists/:id" => "todolists#update", as: "update_todolist"
       #update更新の場合はPATCHで指定
       #updateアクションでは、データの更新後に更新結果を詳細画面に表示するために、
       #showアクションにリダイレクトさせます。このため、新たなViewは作成しません。
  delete 'todolists/:id' => 'todolists#destroy', as: 'destroy_todolist'
       #投稿を削除するには、destroyアクションを用います。
       #destroyアクションでは、データ削除後に一覧画面（indexアクション）へリダイレクトするので、
       #Viewファイルは不要です。
       #HTTPメソッドはDELETE、URLはtodolists/:idです。
       #名前付きパスは、destroy_todolistと設定します。

end