# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '28635e35b233d9e2d91cba245cc9723faab9e81e40c5caec16f086def54ef80bb42a9bc99bab52398307bb471da33a7eb8efecee79572e7c4b6f72a64873eb70'