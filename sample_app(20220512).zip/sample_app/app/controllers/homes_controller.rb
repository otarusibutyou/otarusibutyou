class HomesController < ApplicationController
          #homesControllerはApplivationControllerに引き継ぎます
  def top #defはdefine(定義する)の略。　topトップページを表示するアクションの記述
  end
end
