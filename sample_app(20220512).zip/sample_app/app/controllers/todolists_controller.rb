# coding: utf-8
class TodolistsController < ApplicationController
      #コントローラクラスはModel - View - ControllerのうちControllerを担うコンポーネントで、
      #個々のリクエストに応じた処理を行います。
      #コントローラクラスはApplicationControllerクラス
      #（正確にはその基底クラスであるActionController::Base*8）を継承しているという意味。

#アクション：controllerで定義されるメソッドを指してアクションと呼びます
#→7つ

 def new 
   
    @list = List.new
   
 end 


  def create
    #1 データを新規登録するためのインスタンス作成
    list = List.new(list_params)
    #2 データをデータベースに保存するためのSaveメソッド実行
    list.save
    #3 詳細画面へリダイレクト
     redirect_to todolist_path(list.id)
  end

  def index #データベース内のすべてのデータを取り出すには、Listモデルに対して.allメソッドを使います。
             #List.allメソッドでは、listsテーブルからすべてのデータを取得し、
             #インスタンス変数@listsに代入します。
             #@listsには、一つひとつのデータが配列で入っています。
      @lists = List.all
      #@のついているインスタンス変数はviewファイル→○○.html.erbへ受け渡すことができます。
      
      @list = List.new

  end

  def show
      @list = List.find(params[:id])
      #Controller Action内で定義したインスタンス変数を View へわたす。
      #idを指定してデータを検索するという一連の流れはshowアクションメソッド内に記述します。
      #showアクションは、特定idの内容を表示するアクション
      #findメソッドを使用して検索できるのはidのみ
      #id以外のカラムで検索したい場合、findメソッドではなく、find_by_sqlメソッド等を使用
  end

  def edit
      @list = List.find(params[:id])
  end
      #投稿済みのデータを編集するので、保存されているデータが必要です。
      #findメソッド(データベースから指定したデータを検索する機能)
      #を用いて、データを取得しましょう。

  def update
      #投稿の更新
     list = List.find(params[:id])
     list.update(list_params)
     redirect_to todolist_path(list.id)
     #showアクションにリダイレクトするために、引数には必ずidが
     #必要になります。idを付けることで、
     #どのデータを詳細画面で表示させるのかを決定しています。
  end

  def destroy
      list = List.find(params[:id])
      list.destroy
      redirect_to todolists_path
      #「削除」ボタンをクリックすると、削除リストのid付きでURLが送信されます。
      #list = List.find(params[:id])送られてきた削除idを元にレコードが探され、
      #list.destroyそのレコードを削除します。
      #さらに、destroyメソッドによって、テーブルからデータが削除されます。
      #データ削除後のリダイレクト先は、
      #一覧画面を指すtodolists_path（indexアクション）に設定
  end

  private
  #ストロングパラメータ フォームの入力値をコントローラのcreateやupdateに渡す役割があります。
  #ハッキングなどで不正に入力値を奪われないために、controllerの中でしか呼び出せないようにする役割もあります
  #privateより後に定義されたメソッドは、アクションとして認識されなくなります。
  def list_params
    #list_paramsではフォームで入力されたデータを受け取っています。
    params.require(:list).permit(:title, :body, :image)
    #paramsはRailsで送られてきた値を受け取るためのメソッドです。
    #「params(≒前述したターミナルログのパラメータ)の中からlistを探し、
    #そのlistの中からtitle,bodyを探す。そしてそのtitle,bodyの保存を許可する」
  end
   #privateは一種の境界線で、「ここから下はcontrollerの中でしか呼び出せません」という意味があります。
   #そのため、他のアクション（index,show,createなど）を巻き込まないようにprivateはControllerファイルの一番
   #下のendのすぐ上に書いて下さい。
end
