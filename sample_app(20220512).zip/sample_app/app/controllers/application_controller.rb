class ApplicationController < ActionController::Base
      #ApplicationControllerが継承しているActionController::Baseには、
      #便利なメソッドが多数定義されています。
      #基本的にはapplication〜は全部のページ共通のものを書く。
end
